import sys
import time
from dataclasses import dataclass
from typing import Optional
import numpy as np
from collections import deque

import serial
from serial.tools import list_ports
import matplotlib.pyplot as plt


@dataclass
class Config:
    baud: int = 9600



def pick_port_interactively() -> str:
    """Looks for arduino, lists possible ports, user chooses"""
    ports = list(list_ports.comports())
    if not ports:
        print("No serial ports found. Is the Arduino plugged in?")
        sys.exit(1)

    print("Available serial ports:")
    for i, p in enumerate(ports):
        print(f"  [{i}] {p.device}  ({p.description})")

    while True:
        choice = input("Select port number: ").strip()
        if choice.isdigit():
            idx = int(choice)
            if 0 <= idx < len(ports):
                return ports[idx].device
        print("Invalid selection. Try again.")


def parse_line(line: str) -> Optional[float]:
    """Parsing GSR to return just a float"""
    s = line.strip()
    if not s:
        return None
    if s.lower() in ("start", "stop"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def run_live_plot(port: str, cfg: Config):
    window_size = 50
    buf = deque(maxlen=window_size)

    ser = serial.Serial(port, cfg.baud, timeout=1)
    time.sleep(2.0)  # allow Arduino reset
    ser.reset_input_buffer()

    print("Streaming... Close plot window or press Ctrl+C to stop.")

    plt.ion()
    fig, ax = plt.subplots()
    x_data, y_data = [], []
    (line,) = ax.plot([], [], linewidth=1)

    ax.set_xlabel("Time (s)")
    ax.set_ylabel("GSR")
    ax.set_title("Live GSR")

    start_pc = time.time()

    try:
        while True:
            raw = ser.readline().decode(errors="ignore").strip()
            gsr = parse_line(raw)
            

            if gsr is None:
                continue
            buf.append(gsr)
            smooth_gsr = float(np.mean(buf))


            t_sec = time.time() - start_pc
            x_data.append(t_sec)
            y_data.append(smooth_gsr)
          

            # rolling last 60 seconds
            while x_data and (t_sec - x_data[0] > 60):
                x_data.pop(0)
                y_data.pop(0)
               

            line.set_xdata(x_data)
            line.set_ydata(y_data)

            ax.relim()
            ax.autoscale_view()

            plt.pause(0.01)

    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        ser.close()


def main():
    cfg = Config()
    port = pick_port_interactively()
    run_live_plot(port, cfg)


if __name__ == "__main__":
    main()